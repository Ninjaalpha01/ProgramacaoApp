package gabriel;

public class LimiteInsuficienteException extends Exception {
	public LimiteInsuficienteException() {
		super("Limite insuficiente.");
	}
}
