package gabriel;

public class CartaoBloqueadoException extends Exception {
	public CartaoBloqueadoException() {
		super("Cartao bloqueado.");
	}
}
